﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Comm
{
    public class ProtocolBean
    {
        private int cmId;

        private int msgSeq;

        private int msgLength;

        private string payload;

        public int CmId
        {
            get { return cmId; }
            set { cmId = value; }
        }

        public int MsgSeq
        {
            get { return msgSeq; }
            set { msgSeq = value; }
        }

        public int MsgLength
        {
            get { return msgLength; }
            set { msgLength = value; }
        }

        public string Payload
        {
            get { return payload; }
            set { payload = value; }
        }

        public ProtocolBean(int cmId, int msgSeq, int msgLength, string payload)
        {
            //super();
            this.cmId = cmId;
            this.msgSeq = msgSeq;
            this.msgLength = msgLength;
            this.payload = payload;
        }

        public ProtocolBean()
        {
            //super();
        }

    }
}
