﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Comm
{
    public class ReportDataModel
    {
        private int _id;
        public int ID
        {
            get { return _id; }
            set { _id = value; }
        }

        private int _messagetype;
        public int MessageType
        {
            get { return _messagetype; }
            set { _messagetype = value; }
        }

        private string _sn;
        public string SN
        {
            get { return _sn; }
            set { _sn = value; }
        }

        private string _bicycleno;
        public string BicycleNo
        {
            get { return _bicycleno; }
            set { _bicycleno = value; }
        }

        private decimal _surplusbattery;
        public decimal SurplusBattery
        {
            get { return _surplusbattery; }
            set { _surplusbattery = value; }
        }

        private int _satellite;
        public int Satellite
        {
            get { return _satellite; }
            set { _satellite = value; }
        }

        private int _kickstand;
        public int Kickstand
        {
            get { return _kickstand; }
            set { _kickstand = value; }
        }

        private decimal _totalkm;
        public decimal TotalKM
        {
            get { return _totalkm; }
            set { _totalkm = value; }
        }

        private string _coordinate;
        public string Coordinate
        {
            get { return _coordinate; }
            set { _coordinate = value; }
        }

        private int _chargingstate;
        public int ChargingState
        {
            get { return _chargingstate; }
            set { _chargingstate = value; }
        }

        private int _reason;
        public int Reason
        {
            get { return _reason; }
            set { _reason = value; }
        }

        private string _errorcode;
        public string ErrorCode
        {
            get { return _errorcode; }
            set { _errorcode = value; }
        }

        private int _batteryState;
        public int BatteryState
        {
            get { return _batteryState; }
            set { _batteryState = value; }
        }

        private int _alarmtype;
        public int AlarmType
        {
            get { return _alarmtype; }
            set { _alarmtype = value; }
        }

        private int _chargecount;
        public int ChargeCount
        {
            get { return _chargecount; }
            set { _chargecount = value; }
        }

        private int _emergencybatterystate;
        public int EmergencyBatteryState
        {
            get { return _emergencybatterystate; }
            set { _emergencybatterystate = value; }
        }

        private int _upgradeState;
        public int UpgradeState
        {
            get { return _upgradeState; }
            set { _upgradeState = value; }
        }

        private string _version;
        public string Version
        {
            get { return _version; }
            set { _version = value; }
        }

    }
}
