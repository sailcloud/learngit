﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Comm
{
   public class ProtocolConstant
    {
        public static int HEART_INTERVAL = 30;
        //public static final int HEART_INTERVAL = 180;
        public static int IDLESTATE_CHECK = HEART_INTERVAL + 10;

        // 消息报文最小长度
        public static int MSG_MINLENGTH = 6;

        // 消息报文最长长度
        public static int MSG_MAXLENGTH = 0xFFFF;

        // 当前协议版本
        public static int VERSION = 0x10;
        public static int VERSION_INDEX = 0;

        // 消息类型位置
        public static int CMID_INDEX_START = 1;

        // 报文序列号起始位置
        public static int MSG_SEQ_INDEX_START = 2;

        // 报文消息体长度标识起始位置
        public static int MSG_LENGTH_INDEX_START = 4;
    }
}
