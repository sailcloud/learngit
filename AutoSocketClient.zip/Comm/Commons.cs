﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Comm
{
    public class Commons
    {
        public static int counts = 0;

        /// <summary>
        /// 加密
        /// </summary>
        /// <param name="sn">需加密的字符</param>
        /// <returns>返回加密后的字符串</returns>
        public static string Encryption(string sn)
        {
            char[] arr = sn.ToCharArray();// 字符串转为字符数组 
            Array.Reverse(arr);  // 将数组反转 
            string _strPwd = new String(arr);//反转后的字符串
            byte[] array = System.Text.Encoding.ASCII.GetBytes(_strPwd);//将反转后的字符串转成ascii码
            return Convert.ToBase64String(array);//通过Base64对数组加密，形成加密后的字符串
        }

        /// <summary>
        /// 解密
        /// </summary>
        /// <param name="snEncryption">加密后的密文</param>
        /// <returns>返回解密后的字符串</returns>
        public static string DecryptionSN(string snEncryption)
        {
            byte[] array = Convert.FromBase64String(snEncryption);//通过Base64对加密后的字符串解码成数组
            Array.Reverse(array);  // 将数组反转            
            return System.Text.Encoding.ASCII.GetString(array);//通过ascii恢复出加密前的字符串
        }

        /// <summary>
        /// 转换为地球坐标系
        /// </summary>
        /// <param name="latMinuteValue">纬度的分值</param>
        /// <param name="latDeg">纬度的度值</param>
        /// <param name="lonMinuteValue">经度的分值</param>
        /// <param name="lonDeg">经度的度值</param>
        /// <returns></returns>
        public static string ToCoordinates(double latMinuteValue, double latDeg, double lonMinuteValue, double lonDeg)
        {
            double lat = latMinuteValue / 60 + latDeg;
            double lon = lonMinuteValue / 60 + lonDeg;
            return Wgs84ToGcj02.gps84_To_Gcj02(lat, lon).toString();
            //return lat + "," + lon;
        }

    }
}
