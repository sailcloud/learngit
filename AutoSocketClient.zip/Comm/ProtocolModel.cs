﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Comm
{
    public class ProtocolBaseModel
    {
        private string _sn;
        /// <summary>
        /// sn
        /// </summary>
        public string sn
        {
            get { return _sn; }
            set { _sn = value; }
        }
    }

    /// <summary>
    /// 连接请求Model
    /// </summary>
    public class ProtocolConnReqModel
    {
        private string _sn;
        /// <summary>
        /// sn
        /// </summary>
        public string sn
        {
            get { return _sn; }
            set { _sn = value; }
        }

        private string _timeStamp;
        /// <summary>
        /// 时间戳
        /// </summary>
        public string timeStamp
        {
            get { return _timeStamp; }
            set { _timeStamp = value; }
        }

        private string _btid;
        /// <summary>
        /// 蓝牙ID号
        /// </summary>
        public string BTID
        {
            get { return _btid; }
            set { _btid = value; }
        }

        private string _bmsid;
        /// <summary>
        /// BMS ID号
        /// </summary>
        public string BMSID
        {
            get { return _bmsid; }
            set { _bmsid = value; }
        }

        private string _authkey;
        /// <summary>
        /// 验证(md5摘要签名编码采用UTF-8，16位小写)
        /// </summary>
        public string authKey
        {
            get { return _authkey; }
            set { _authkey = value; }
        }

    }

    /// <summary>
    /// 连接响应Model
    /// </summary>
    public class ProtocolConnRespModel
    {
        private string _sn;
        /// <summary>
        /// sn
        /// </summary>
        public string sn
        {
            get { return _sn; }
            set { _sn = value; }
        }

        private int _needlock;
        /// <summary>
        /// 通讯模块是否需要上锁(0 解锁状态 1 上锁状态)
        /// </summary>
        public int needLock
        {
            get { return _needlock; }
            set { _needlock = value; }
        }

        private int _result;
        /// <summary>
        /// 连接是否成功（0：连接成功，无车辆号返回；1：连接成功，有车辆号返回；2：连接失败；）
        /// </summary>
        public int result
        {
            get { return _result; }
            set { _result = value; }
        }

        private string _bikeid;
        /// <summary>
        /// 车辆号
        /// </summary>
        public string bikeID
        {
            get { return _bikeid; }
            set { _bikeid = value; }
        }
    }

    /// <summary>
    /// 上报数据请求Model
    /// </summary>
    public class ProtocolReportReqModel
    {
        private string _sn;
        /// <summary>
        /// sn
        /// </summary>
        public string sn
        {
            get { return _sn; }
            set { _sn = value; }
        }

        private int _messageType;
        /// <summary>
        /// 1：开锁状态下每 20s 上报一次的信息；
        /// 2：未开锁状态下每 5min 上报一次的信息；
        /// 3：由车辆开始充电触发的上报信息； 
        /// 4：由车辆断开充电触发的上报信息； 
        /// 5：由车辆报警触发的上报信息； 
        /// 6：由车辆自动上锁触发的上报信息； 
        /// 8：历史位置数据上报信息； 
        /// 9：低功耗模式下周期上报消息（启用备用电 池的情况） 
        /// 10：OTA 固件升级结果上报信息； 
        /// </summary>
        public int messageType
        {
            get { return _messageType; }
            set { _messageType = value; }
        }

        private MessageBodyModel _messagebody;
        /// <summary>
        /// 信息主体
        /// </summary>
        public MessageBodyModel messageBody
        {
            get { return _messagebody; }
            set { _messagebody = value; }
        }
    }

    public class MessageBodyModel
    {
        private double _latitudeDegree;
        /// <summary>
        /// 纬度度值
        /// </summary>
        public double latitudeDegree
        {
            get { return _latitudeDegree; }
            set { _latitudeDegree = value; }
        }

        private double _latitudeMinute;
        /// <summary>
        /// 纬度分值
        /// </summary>
        public double latitudeMinute
        {
            get { return _latitudeMinute; }
            set { _latitudeMinute = value; }
        }

        private double _longitudeDegree;
        /// <summary>
        /// 经度度值
        /// </summary>
        public double longitudeDegree
        {
            get { return _longitudeDegree; }
            set { _longitudeDegree = value; }
        }

        private double _longitudeMinute;
        /// <summary>
        /// 经度分值
        /// </summary>
        public double longitudeMinute
        {
            get { return _longitudeMinute; }
            set { _longitudeMinute = value; }
        }

        private decimal _totalMileage;
        /// <summary>
        /// 车辆行驶总里程（单位：KM）
        /// </summary>
        public decimal totalMileage
        {
            get { return _totalMileage; }
            set { _totalMileage = value; }
        }

        private decimal _battery;
        /// <summary>
        /// 电池剩余电量(50即电量50%)
        /// </summary>
        public decimal battery
        {
            get { return _battery; }
            set { _battery = value; }
        }

        private int _satellite;
        /// <summary>
        /// GPS 卫星数
        /// </summary>
        public int satellite
        {
            get { return _satellite; }
            set { _satellite = value; }
        }

        private int _chargeCount;
        /// <summary>
        /// 电池充电总循环数
        /// </summary>
        public int chargeCount
        {
            get { return _chargeCount; }
            set { _chargeCount = value; }
        }

        private bool _charging;
        /// <summary>
        /// 电池充电状态(true：充电 false：未充电)
        /// </summary>
        public bool charging
        {
            get { return _charging; }
            set { _charging = value; }
        }

        private string _errorCode;
        /// <summary>
        /// 故障码
        /// </summary>
        public string errorCode
        {
            get { return _errorCode; }
            set { _errorCode = value; }
        }

        private bool _reason;
        /// <summary>
        /// 断开原因（true: 正常断开 false：保护断开）
        /// </summary>
        public bool reason
        {
            get { return _reason; }
            set { _reason = value; }
        }

        private int _alarmType;
        /// <summary>
        /// 报警类型 (1：侧翻报警； 2：非法触碰报警； 3：非法位移报警)
        /// </summary>
        public int alarmType
        {
            get { return _alarmType; }
            set { _alarmType = value; }
        }

        private List<LocationInfoModel> _location;
        /// <summary>
        /// 历史数据
        /// </summary>
        public List<LocationInfoModel> location
        {
            get { return _location; }
            set { _location = value; }
        }

        private int _result;
        /// <summary>
        /// 固件升级结果(0：成功 1：失败 )
        /// </summary>
        public int result
        {
            get { return _result; }
            set { _result = value; }
        }

        private string _version;
        /// <summary>
        /// 当前运行版本号 
        /// </summary>
        public string version
        {
            get { return _version; }
            set { _version = value; }
        }

        private int _ctrlState;
        /// <summary>
        /// 控制器工作状态(1无电 2工作模式 3防盗模式)
        /// </summary>
        public int ctrlState
        {
            get { return _ctrlState; }
            set { _ctrlState = value; }
        }

        private int _kickstand;
        /// <summary>
        /// 脚撑状态(0: 表示脚撑支起 1：表示脚撑抬起)
        /// </summary>
        public int kickstand
        {
            get { return _kickstand; }
            set { _kickstand = value; }
        }

        private int _gpstype;
        /// <summary>
        /// GPS定位状态(0：GPS从未定位过 1：GPS实时定位 2：GPS位置过去有效)
        /// </summary>
        public int gpstype
        {
            get { return _gpstype; }
            set { _gpstype = value; }
        }

        private string _cellid;
        /// <summary>
        /// 基站ID
        /// </summary>
        public string cellId
        {
            get { return _cellid; }
            set { _cellid = value; }
        }

    }

    //public class LocationModel
    //{
    //    private List<LocationInfoModel> _location;
    //    public List<LocationInfoModel> location
    //    {
    //        get { return _location; }
    //        set { _location = value; }
    //    }
    //}

    public class LocationInfoModel
    {
        private double _latitudeMinute;
        private double _latitudeDegree;
        private double _longitudeMinute;
        private double _longitudeDegree;
        private string _at;
        private decimal _totalMileage;

        public double latitudeMinute
        {
            get { return _latitudeMinute; }
            set { _latitudeMinute = value; }
        }
        public double latitudeDegree
        {
            get { return _latitudeDegree; }
            set { _latitudeDegree = value; }
        }
        public double longitudeMinute
        {
            get { return _longitudeMinute; }
            set { _longitudeMinute = value; }
        }
        public double longitudeDegree
        {
            get { return _longitudeDegree; }
            set { _longitudeDegree = value; }
        }
        public string at
        {
            get { return _at; }
            set { _at = value; }
        }
        public decimal totalMileage
        {
            get { return _totalMileage; }
            set { _totalMileage = value; }
        }


    }

    /// <summary>
    /// 命令请求Model
    /// </summary>
    public class ProtocolCMDReqModel
    {
        private string _sn;
        /// <summary>
        /// SN
        /// </summary>
        public string sn
        {
            get { return _sn; }
            set { _sn = value; }
        }

        private int _cmdId;
        /// <summary>
        /// 命令ID
        /// </summary>
        public int cmdID
        {
            get { return _cmdId; }
            set { _cmdId = value; }
        }

        private ArgumentModel _argument;
        /// <summary>
        /// 命令参数
        /// </summary>
        public ArgumentModel argument
        {
            get { return _argument; }
            set { _argument = value; }
        }
    }

    /// <summary>
    /// 命令参数
    /// </summary>
    public class ArgumentModel
    {
        private int _maxSpeed;
        /// <summary>
        /// 车辆行驶最大速度
        /// </summary>
        public int maxSpeed
        {
            get { return _maxSpeed; }
            set { _maxSpeed = value; }
        }

        private string _version;
        /// <summary>
        /// 最近固件版本号
        /// </summary>
        public string version
        {
            get { return _version; }
            set { _version = value; }
        }

        private string _ftpAddr;
        /// <summary>
        /// FTP服务器IP地址
        /// </summary>
        public string ftpAddr
        {
            get { return _ftpAddr; }
            set { _ftpAddr = value; }
        }

        private int _ftpPort;
        /// <summary>
        /// FTP服务器端口
        /// </summary>
        public int ftpPort
        {
            get { return _ftpPort; }
            set { _ftpPort = value; }
        }

        private string _userID;
        /// <summary>
        /// FTP服务器用户ID
        /// </summary>
        public string userID
        {
            get { return _userID; }
            set { _userID = value; }
        }

        private string _passwd;
        /// <summary>
        /// FTP服务器登录密码
        /// </summary>
        public string passwd
        {
            get { return _passwd; }
            set { _passwd = value; }
        }

        private string _filePath;
        /// <summary>
        /// 固件在FTP上的位置
        /// </summary>
        public string filePath
        {
            get { return _filePath; }
            set { _filePath = value; }
        }

        private string _fileName;
        /// <summary>
        /// 固件名称
        /// </summary>
        public string fileName
        {
            get { return _fileName; }
            set { _fileName = value; }
        }

        private int _fileSize;
        /// <summary>
        /// 固件大小
        /// </summary>
        public int fileSize
        {
            get { return _fileSize; }
            set { _fileSize = value; }
        }

        private string _md5;
        /// <summary>
        /// 固件MD5码
        /// </summary>
        public string MD5
        {
            get { return _md5; }
            set { _md5 = value; }
        }

        private bool _alarmEnable;
        /// <summary>
        /// 告警（侧翻、碰撞、非法位移）开关
        /// (true:告警开 false:告警关)
        /// </summary>
        public bool alarmEnable
        {
            get { return _alarmEnable; }
            set { _alarmEnable = value; }
        }

        private string _voiceid;
        /// <summary>
        /// 语音ID
        /// </summary>
        public string voiceId
        {
            get { return _voiceid; }
            set { _voiceid = value; }
        }

    }


    public class ProtocolCMDRespModel
    {
        private string _sn;
        public string sn
        {
            get { return _sn; }
            set { _sn = value; }
        }

        private int _cmdId;
        /// <summary>
        /// 1：车辆开锁命令； 
        /// 2：车辆上锁命令； 
        /// 3：车辆状态查询命令； 
        /// 4：寻车命令； 
        /// 5：大灯闪烁命令； 
        /// 6：打开电池仓命令； 
        /// 7：最大行驶速度设定命令； 
        /// 8：OTA 远程固件升级命令； 
        /// 9：服务器告警使能命令； 
        /// </summary>
        public int cmdID
        {
            get { return _cmdId; }
            set { _cmdId = value; }
        }

        private int _result;
        /// <summary>
        /// 成功指示（true 成功，false 失败）
        /// </summary>
        public int result
        {
            get { return _result; }
            set { _result = value; }
        }

        private CMDData _data;
        /// <summary>
        /// 命令响应返回参数
        /// </summary>
        public CMDData data
        {
            get { return _data; }
            set { _data = value; }
        }
    }

    public class CMDData
    {
        private double _latitudeDegree;
        /// <summary>
        /// 纬度度值
        /// </summary>
        public double latitudeDegree
        {
            get { return _latitudeDegree; }
            set { _latitudeDegree = value; }
        }

        private double _latitudeMinute;
        /// <summary>
        /// 纬度分值
        /// </summary>
        public double latitudeMinute
        {
            get { return _latitudeMinute; }
            set { _latitudeMinute = value; }
        }

        private double _longitudeDegree;
        /// <summary>
        /// 经度度值
        /// </summary>
        public double longitudeDegree
        {
            get { return _longitudeDegree; }
            set { _longitudeDegree = value; }
        }

        private double _longitudeMinute;
        /// <summary>
        /// 经度分值
        /// </summary>
        public double longitudeMinute
        {
            get { return _longitudeMinute; }
            set { _longitudeMinute = value; }
        }

        private decimal _totalMileage;
        /// <summary>
        /// 总里程
        /// </summary>
        public decimal totalMileage
        {
            get { return _totalMileage; }
            set { _totalMileage = value; }
        }

        private decimal _battery;
        /// <summary>
        /// 电池剩余电量(50即电量50%)
        /// </summary>
        public decimal battery
        {
            get { return _battery; }
            set { _battery = value; }
        }

        private int _satellite;
        /// <summary>
        /// GPS 卫星数
        /// </summary>
        public int satellite
        {
            get { return _satellite; }
            set { _satellite = value; }
        }

        private int _chargeCount;
        /// <summary>
        /// 电池充电总循环数
        /// </summary>
        public int chargeCount
        {
            get { return _chargeCount; }
            set { _chargeCount = value; }
        }

        private bool _charging;
        /// <summary>
        /// 电池充电状态(true：充电 false：未充电)
        /// </summary>
        public bool charging
        {
            get { return _charging; }
            set { _charging = value; }
        }

        private string _errorCode;
        /// <summary>
        /// 故障码
        /// </summary>
        public string errorCode
        {
            get { return _errorCode; }
            set { _errorCode = value; }
        }

        private int _ctrlState;
        /// <summary>
        /// 控制器工作状态
        /// </summary>
        public int ctrlState
        {
            get { return _ctrlState; }
            set { _ctrlState = value; }
        }
    }


    /// <summary>
    /// 车辆心跳请求Model
    /// </summary>
    public class ProtocolHeartbeatModel
    {
        private string _sn;
        /// <summary>
        /// SN
        /// </summary>
        public string sn
        {
            get { return _sn; }
            set { _sn = value; }
        }
    }

    /// <summary>
    /// 远程设置请求Model
    /// </summary>
    public class ProtocolSETReqModel
    {
        private string _sn;
        /// <summary>
        /// SN
        /// </summary>
        public string sn
        {
            get { return _sn; }
            set { _sn = value; }
        }

        private string _opname;
        /// <summary>
        /// 操作码
        /// </summary>
        public string opname
        {
            get { return _opname; }
            set { _opname = value; }
        }

        private string _paramname;
        /// <summary>
        /// 参数名称
        /// </summary>
        public string paramname
        {
            get { return _paramname; }
            set { _paramname = value; }
        }

        private string _paramvalue;
        /// <summary>
        /// 参数值
        /// </summary>
        public string paramvalue
        {
            get { return _paramvalue; }
            set { _paramvalue = value; }
        }
    }

    /// <summary>
    /// 远程设置应答Model
    /// </summary>
    public class ProtocolSETRespModel
    {
        private string _sn;
        /// <summary>
        /// SN
        /// </summary>
        public string sn
        {
            get { return _sn; }
            set { _sn = value; }
        }

        private string _paramname;
        /// <summary>
        /// 参数名称
        /// </summary>
        public string paramname
        {
            get { return _paramname; }
            set { _paramname = value; }
        }

        private int _result;
        /// <summary>
        /// 设置结果(0：成功 1：失败)
        /// </summary>
        public int result
        {
            get { return _result; }
            set { _result = value; }
        }
    }

    /// <summary>
    /// 远程查询数据请求Model
    /// </summary>
    public class ProtocolGETReqModel
    {
        private string _sn;
        /// <summary>
        /// 
        /// </summary>
        public string sn
        {
            get { return _sn; }
            set { _sn = value; }
        }

        private string _opname;
        /// <summary>
        /// 操作码
        /// </summary>
        public string opname
        {
            get { return _opname; }
            set { _opname = value; }
        }

        private string _paramname;
        /// <summary>
        /// 参数名称
        /// </summary>
        public string paramname
        {
            get { return _paramname; }
            set { _paramname = value; }
        }

    }
    /// <summary>
    /// 远程查询数据应答Model
    /// </summary>
    public class ProtocolGETRespModel
    {
        private string _sn;
        /// <summary>
        /// SN
        /// </summary>
        public string sn
        {
            get { return _sn; }
            set { _sn = value; }
        }

        private string _paramname;
        /// <summary>
        /// 参数名称
        /// </summary>
        public string paramname
        {
            get { return _paramname; }
            set { _paramname = value; }
        }

        private string _paramvalue;
        /// <summary>
        /// 参数值
        /// </summary>
        public string paramvalue
        {
            get { return _paramvalue; }
            set { _paramvalue = value; }
        }

    }

    /// <summary>
    /// 固件请求Model
    /// </summary>
    public class ProtocolFirmwareReqModel
    {
        private string _sn;
        /// <summary>
        /// SN
        /// </summary>
        public string sn
        {
            get { return _sn; }
            set { _sn = value; }
        }

        private int _clientcode;
        /// <summary>
        /// 客户代码
        /// </summary>
        public int clientcode
        {
            get { return _clientcode; }
            set { _clientcode = value; }
        }

        private int _hdcode;
        /// <summary>
        /// 硬件型号
        /// </summary>
        public int hdcode
        {
            get { return _hdcode; }
            set { _hdcode = value; }
        }

        private string _version;
        /// <summary>
        /// 固件版本号
        /// </summary>
        public string version
        {
            get { return _version; }
            set { _version = value; }
        }

        private int _filetype;
        /// <summary>
        /// 固件类型(0：ECU主控制器固件 1：蓝牙固件 2：BMS固件)
        /// </summary>
        public int filetype
        {
            get { return _filetype; }
            set { _filetype = value; }
        }

        private int _blocktype;
        /// <summary>
        /// 分块机制(0：240个字节 1：480个字节 2：960个字节)
        /// </summary>
        public int blocktype
        {
            get { return _blocktype; }
            set { _blocktype = value; }
        }

        private int _blocknum;
        /// <summary>
        /// 数据块编号
        /// </summary>
        public int blocknum
        {
            get { return _blocknum; }
            set { _blocknum = value; }
        }


    }



}
