﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Comm
{
    public class ReturnMesModel
    {
        public string returnCode { get; set; }
        public string returnMsg { get; set; }
        public object Data { get; set; }
        public object Data1 { get; set; }
    }
}
