﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Comm
{
    public enum MessageSeqEnum
    {
        /// <summary>
        /// 自动还车操作
        /// </summary>
        AutoCode = 100,
        /// <summary>
        /// 用户操作
        /// </summary>
        UserCode = 101,
        /// <summary>
        /// 运维人员操作
        /// </summary>
        OperCode = 102,
        /// <summary>
        /// 其它长连接
        /// </summary>
        Other = 105,

        /// <summary>
        /// 客服还车
        /// </summary>
        Customer = 103,

        //并发计数基础索引，必须是这个里面最大的数值
        MaxCode = 110
    }
}
