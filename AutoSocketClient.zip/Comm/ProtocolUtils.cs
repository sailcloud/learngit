﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;
using System.Collections;
using Newtonsoft.Json;

namespace Comm
{
    public class ProtocolUtils
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static String GetMD5(String str)
        {
            MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider();
            string builder = BitConverter.ToString(md5.ComputeHash(UTF8Encoding.Default.GetBytes(str)), 4, 8);
            builder = builder.Replace("-", "");
            return builder;

            //MD5 md5Hash = MD5.Create();
            //byte[] data = md5Hash.ComputeHash(Encoding.UTF8.GetBytes(str + "MimaCX"));
            //StringBuilder builder = new StringBuilder();
            //for (int i = 0; i < data.Length; i++)
            //{
            //    builder.Append(data[i].ToString("x2"));
            //}
            //return builder.ToString();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="byte_1"></param>
        /// <param name="byte_2"></param>
        /// <returns></returns>
        public static byte[] byteMerger(byte[] byte_1, byte[] byte_2)
        {
            byte[] byte_3 = new byte[byte_1.Length + byte_2.Length];
            Buffer.BlockCopy(byte_1, 0, byte_3, 0, byte_1.Length);
            Buffer.BlockCopy(byte_2, 0, byte_3, byte_1.Length, byte_2.Length);
            return byte_3;
        }

        /// <summary>
        /// 编码消息头
        /// </summary>
        /// <param name="cmId"></param>
        /// <param name="msgLength"></param>
        /// <param name="msgSeq"></param>
        /// <returns></returns>
        public static byte[] encodeHead(int cmId, int msgLength, int msgSeq)
        {
            if (ProtocolConstant.MSG_MAXLENGTH < msgLength)
            {
                throw new Exception("msgLength is too long");
            }
            byte[] headbyte = new byte[6];
            headbyte[ProtocolConstant.VERSION_INDEX] = (byte)(ProtocolConstant.VERSION);
            headbyte[ProtocolConstant.CMID_INDEX_START] = (byte)(cmId & 0xff);
            headbyte[ProtocolConstant.MSG_SEQ_INDEX_START] = (byte)((msgSeq & 0xff00) >> 8);
            headbyte[ProtocolConstant.MSG_SEQ_INDEX_START + 1] = (byte)(msgSeq & 0xff);
            headbyte[ProtocolConstant.MSG_LENGTH_INDEX_START] = (byte)((msgLength & 0xff00) >> 8);
            headbyte[ProtocolConstant.MSG_LENGTH_INDEX_START + 1] = (byte)(msgLength & 0xff);
            return headbyte;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="cmId"></param>
        /// <param name="jbMsg"></param>
        /// <param name="msgSeq"></param>
        /// <returns></returns>
        public static byte[] encode(int cmId, Hashtable jbMsg, int msgSeq)
        {
            byte[] encodeByte = null;
            String payload = JsonConvert.SerializeObject(jbMsg);
            byte[] payloadByte = Encoding.UTF8.GetBytes(payload);
            byte[] headByte = encodeHead(cmId, payloadByte.Length, msgSeq);
            encodeByte = byteMerger(headByte, payloadByte);
            return encodeByte;
        }

        public static ProtocolBean decode(byte[] decodebytes)
        {
            ProtocolBean pBean = new ProtocolBean();

            byte version = decodebytes[ProtocolConstant.VERSION_INDEX];
            if (version != (byte)(ProtocolConstant.VERSION))
            {
                throw new Exception("head version error");
            }

            int cmId = decodebytes[ProtocolConstant.CMID_INDEX_START];
            pBean.CmId = cmId;

            int msgSeq = (decodebytes[ProtocolConstant.MSG_SEQ_INDEX_START] & 0xff) << 8 | decodebytes[ProtocolConstant.MSG_SEQ_INDEX_START + 1];
            pBean.MsgSeq = msgSeq;

            int payloadIndex = ProtocolConstant.MSG_LENGTH_INDEX_START;
            int payloadLength = (decodebytes[payloadIndex] & 0xff) << 8 | decodebytes[payloadIndex + 1];
            pBean.MsgLength = payloadLength;

            int wholeLength = payloadLength + 6;
            //if (wholeLength != decodebytes.Length)
            //{
            //    throw new Exception("payload length error");
            //}

            try
            {
                String payloadStr = Encoding.UTF8.GetString(decodebytes, 6, payloadLength);
                //pBean.Payload =JsonConvert.SerializeObject(payloadStr);
                pBean.Payload = payloadStr;
            }
            catch (Exception e)
            {
                // TODO Auto-generated catch block
                //e.printStackTrace();
            }
            return pBean;
        }


    }
}
