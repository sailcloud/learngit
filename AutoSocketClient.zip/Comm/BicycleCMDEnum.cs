﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Comm
{
    public enum BicycleCMDEnum
    {
        /// <summary>
        /// 开锁
        /// </summary>
        Open = 1,

        /// <summary>
        /// 上锁
        /// </summary>
        Lock = 2,

        /// <summary>
        /// 查询车辆状态
        /// </summary>
        QueryState = 3,

        /// <summary>
        /// 寻车
        /// </summary>
        Call = 4,

        /// <summary>
        /// 闪灯
        /// </summary>
        Bright = 5,

        /// <summary>
        /// 打开电池仓
        /// </summary>
        Battary = 6,

        /// <summary>
        /// 设定最大行驶速度
        /// </summary>
        SetMaxSpeed = 7,

        /// <summary>
        /// 远程固件升级
        /// </summary>
        UpgradeOTA = 8,

        /// <summary>
        /// 设置车辆报警状态
        /// </summary>
        SetAlarmState = 9,

        /// <summary>
        /// 远程恢复出厂设置
        /// </summary>
        Reset = 10,

        /// <summary>
        /// 定位
        /// </summary>
        Coordinates = 11,

        /// <summary>
        /// 重启
        /// </summary>
        Restart = 12,

        /// <summary>
        /// 语音
        /// </summary>
        Voice = 15,


    }
}
