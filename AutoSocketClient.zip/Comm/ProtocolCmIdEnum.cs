﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Comm
{
    /// <summary>
    /// 
    /// </summary>
    public enum ProtocolCmIdEnum
    {
        /// <summary>
        /// 连接请求
        /// </summary>
        CONN_REQ = 1,

        /// <summary>
        /// 连接响应
        /// </summary>
        CONN_RESP = 2,

        /// <summary>
        /// 数据/事件上报
        /// </summary>
        REPORT_DATA = 3,

        /// <summary>
        /// 数据/事件上报响应
        /// </summary>
        REPORT_ACK = 4,

        /// <summary>
        /// 命令请求
        /// </summary>
        CMD_REQ = 5,

        /// <summary>
        /// 命令响应
        /// </summary>
        CMD_RESP = 6,

        /// <summary>
        /// 心跳请求
        /// </summary>
        PING_REQ = 7,

        /// <summary>
        /// 心跳响应
        /// </summary>
        PING_RESP = 8,

        /// <summary>
        /// AGPS数据请求
        /// </summary>
        AGPS_REQ = 9,

        /// <summary>
        /// AGPS数据回复
        /// </summary>
        AGPS_RESP = 10,

        /// <summary>
        /// 自动还车心跳请求
        /// </summary>
        AUTO_HEARTBEAT_REQ = 11,

        /// <summary>
        /// 自动还车心跳响应
        /// </summary>
        AUTO_HEARTBEAT_RESP = 12,
        /// <summary>
        /// 服务器通知车升级请求
        /// </summary>
        FIRMWARE_TBT_REQ = 13,
        /// <summary>
        /// 自动还车命令请求
        /// </summary>
        AUTO_CMD_REQ = 15,

        /// <summary>
        /// 自动还车命令响应
        /// </summary>
        AUTO_CMD_RESP = 16,
        /// <summary>
        /// 远程设置
        /// </summary>
        SET_REQ = 17,
        /// <summary>
        /// 远程设置数据回复
        /// </summary>
        SET_RESP = 18,
        /// <summary>
        /// 远程查询
        /// </summary>
        GET_REQ = 19,
        /// <summary>
        /// 远程查询数据回复
        /// </summary>
        GET_RESP = 20,

        /// <summary>
        /// 车辆向服务器发升级请求数据消息
        /// </summary>
        FIRMWARE_REQ = 21,

        /// <summary>
        /// 服务器下发升级包
        /// </summary>
        FIRMWARE_RESP = 22






    }
}
