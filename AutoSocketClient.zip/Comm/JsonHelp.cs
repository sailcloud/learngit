﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace Comm
{
    public class JsonHelp
    {
        public static string GetJsonValue(string jsonStr, string key)
        {
            try
            {
                JavaScriptSerializer JSS = new JavaScriptSerializer();
                object obj = JSS.DeserializeObject(jsonStr);
                Dictionary<string, object> datajson = (Dictionary<string, object>)obj;

                foreach (var item in datajson)
                {
                    if (item.Value.GetType().ToString().Trim() == "System.Collections.Generic.Dictionary'2[System.String.System.Object]")
                    {
                        Dictionary<string, object> rows = (Dictionary<string, object>)item.Value;
                        foreach (var items in rows)
                        {
                            if (items.Key.Trim() == key)
                            {
                                return items.Value.ToString();
                            }
                        }
                    }
                    if (item.Key.Trim() == key)
                    {
                        return item.Value.ToString();
                    }
                }
                return string.Empty;
            }
            catch (Exception ex)
            {
                return string.Empty;
            }
        }

    }
}
