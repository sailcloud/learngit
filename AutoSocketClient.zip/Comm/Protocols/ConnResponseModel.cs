﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Comm
{
    public class ConnResponseModel
    {
        private string _sn;
        public string sn
        {
            get { return _sn; }
            set { _sn = value; }
        }

        private int _result;
        public int result
        {
            get { return _result; }
            set { _result = value; }
        }

        private string _bikeID;
        public string bikeID
        {
            get { return _bikeID; }
            set { _bikeID = value; }
        }
    }
}
