﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Comm
{
    public class ReprotResponseModel
    {
        private string _sn;
        public string sn
        {
            get { return _sn; }
            set { _sn = value; }
        }

        private int _messageType;
        public int messageType
        {
            get { return _messageType; }
            set { _messageType = value; }
        }

        private int _result;
        public int result
        {
            get { return _result; }
            set { _result = value; }
        }



    }
}
