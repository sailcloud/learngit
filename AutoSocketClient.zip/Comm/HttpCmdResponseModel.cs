﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Comm
{
    public class HttpCmdResponseModel
    {
        private int _cmid;
        public int CmId
        {
            get { return _cmid; }
            set { _cmid = value; }
        }

        private int _msgseq;
        public int MsgSeq
        {
            get { return _msgseq; }
            set { _msgseq = value; }
        }

        private int _msglength;
        public int MsgLength
        {
            get { return _msglength; }
            set { _msglength = value; }
        }

        private HttpPayload _payload;
        public HttpPayload Payload
        {
            get { return _payload; }
            set { _payload = value; }
        }
    }

    public class HttpPayload
    {
        private string _sn;
        public string sn
        {
            get { return _sn; }
            set { _sn = value; }
        }

        private int _cmdid;
        private int cmdID
        {
            get { return _cmdid; }
            set { _cmdid = value; }
        }

        private int _result;
        public int result
        {
            get { return _result; }
            set { _result = value; }
        }

        private HttpData _data;
        public HttpData data
        {
            get { return _data; }
            set { _data = value; }
        }

    }

    public class HttpData
    {
        private double _latitudeDegree;
        public double latitudeDegree
        {
            get { return _latitudeDegree; }
            set { _latitudeDegree = value; }
        }

        private double _latitudeMinute;
        public double latitudeMinute
        {
            get { return _latitudeMinute; }
            set { _latitudeMinute = value; }
        }

        private double _longitudeDegree;
        public double longitudeDegree
        {
            get { return _longitudeDegree; }
            set { _longitudeDegree = value; }
        }

        private double _longitudeMinute;
        public double longitudeMinute
        {
            get { return _longitudeMinute; }
            set { _longitudeMinute = value; }
        }

        private decimal _totalMileage;
        public decimal totalMileage
        {
            get { return _totalMileage; }
            set { _totalMileage = value; }
        }

        private decimal _battery;
        public decimal battery
        {
            get { return _battery; }
            set { _battery = value; }
        }

        private int _satellite;
        public int satellite
        {
            get { return _satellite; }
            set { _satellite = value; }
        }

        private int _chargeCount;
        public int chargeCount
        {
            get { return _chargeCount; }
            set { _chargeCount = value; }
        }

        private bool _charging;
        public bool charging
        {
            get { return _charging; }
            set { _charging = value; }
        }

        private string _errorcode;
        public string errorCode
        {
            get { return _errorcode; }
            set { _errorcode = value; }
        }

        private int _ctrlstate;
        public int ctrlState
        {
            get { return _ctrlstate; }
            set { _ctrlstate = value; }
        }


    }
}
