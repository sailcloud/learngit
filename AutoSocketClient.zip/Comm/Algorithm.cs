﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Comm
{
    public class Algorithm
    {
        private static byte EncryptionKey = (byte)0x5a;

        /// <summary>
        /// 加密
        /// </summary>
        /// <param name="depth"></param>
        /// <param name="pData"></param>
        /// <param name="count"></param>
        public static void ByteEncryption(int depth, byte[] pData, int count)
        {
            int n = 0, i = 0;
            byte data = 0;
            byte pdata = 0;
            for (n = 0; n < depth; n++)
            {
                for (i = 0; i < count; i++)
                {
                    data = 0;
                    pdata = pData[i];
                    data |= (byte)((pdata & 0x01) << 3);
                    data |= (byte)((pdata & 0x02) << 1);
                    data |= (byte)((pdata & 0x04) << 3);
                    data |= (byte)((pdata & 0x08) << 4);
                    data |= (byte)((pdata & 0x10) >> 3);
                    data |= (byte)((pdata & 0x20) >> 1);
                    data |= (byte)((pdata & 0x40) >> 6);
                    data |= (byte)((pdata & 0x80) >> 1);
                    data = (byte)(data - EncryptionKey);
                    pData[i] = data;
                }
            }
        }

        /// <summary>
        /// 解密
        /// </summary>
        /// <param name="depth"></param>
        /// <param name="pData"></param>
        /// <param name="count"></param>
        public static void ByteDecryption(int depth, byte[] pData, int count)
        {
            int n = 0, i = 0;
            byte data = 0;
            byte pdata = 0;
            for (n = 0; n < depth; n++)
            {
                for (i = 0; i < count; i++)
                {
                    data = 0;
                    pdata = (byte)(pData[i] + EncryptionKey);
                    data |= (byte)((pdata & 0x01) << 6);
                    data |= (byte)((pdata & 0x02) << 3);
                    data |= (byte)((pdata & 0x04) >> 1);
                    data |= (byte)((pdata & 0x08) >> 3);
                    data |= (byte)((pdata & 0x10) << 1);
                    data |= (byte)((pdata & 0x20) >> 3);
                    data |= (byte)((pdata & 0x40) << 1);
                    data |= (byte)((pdata & 0x80) >> 4);
                    pData[i] = data;
                }
            }
        }


        /// <summary>
        /// 加密
        /// </summary>
        /// <param name="str">需加密的字符串</param>
        public static string Encryption(string str)
        {
            char[] arr = str.ToCharArray();// 字符串转为字符数组 
            Array.Reverse(arr);  // 将数组反转 
            string _strPwd = new String(arr);//反转后的字符串
            byte[] array = System.Text.Encoding.ASCII.GetBytes(_strPwd);//将反转后的字符串转成ascii码
            return Convert.ToBase64String(array);//通过Base64对数组加密，形成加密后的字符串
        }

        /// <summary>
        /// 解密
        /// </summary>
        /// <param name="str">需解密的字符串</param>
        public static string Decryption(string str)
        {
            byte[] array = Convert.FromBase64String(str);//通过Base64对加密后的字符串解码成数组
            Array.Reverse(array);  // 将数组反转            
            return System.Text.Encoding.ASCII.GetString(array);//通过ascii恢复出加密前的字符串
        }


    }
}
