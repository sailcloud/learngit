﻿namespace CMDTEST
{
    partial class CMD_Form
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.btnOpenLock = new System.Windows.Forms.Button();
            this.btnLock = new System.Windows.Forms.Button();
            this.btnQueryState = new System.Windows.Forms.Button();
            this.btnBright = new System.Windows.Forms.Button();
            this.txtData = new System.Windows.Forms.RichTextBox();
            this.btnCall = new System.Windows.Forms.Button();
            this.btnOpenBattery = new System.Windows.Forms.Button();
            this.btnSetMaxSpeed = new System.Windows.Forms.Button();
            this.btnUpgrade = new System.Windows.Forms.Button();
            this.btnSetAlarm = new System.Windows.Forms.Button();
            this.txtSN = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnConnect = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.btnSet = new System.Windows.Forms.Button();
            this.btnGet = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnOpenLock
            // 
            this.btnOpenLock.Location = new System.Drawing.Point(9, 52);
            this.btnOpenLock.Name = "btnOpenLock";
            this.btnOpenLock.Size = new System.Drawing.Size(75, 23);
            this.btnOpenLock.TabIndex = 0;
            this.btnOpenLock.Text = "开锁";
            this.btnOpenLock.UseVisualStyleBackColor = true;
            this.btnOpenLock.Click += new System.EventHandler(this.btnOpenLock_Click);
            // 
            // btnLock
            // 
            this.btnLock.Location = new System.Drawing.Point(90, 52);
            this.btnLock.Name = "btnLock";
            this.btnLock.Size = new System.Drawing.Size(75, 23);
            this.btnLock.TabIndex = 1;
            this.btnLock.Text = "上锁";
            this.btnLock.UseVisualStyleBackColor = true;
            this.btnLock.Click += new System.EventHandler(this.btnLock_Click);
            // 
            // btnQueryState
            // 
            this.btnQueryState.Location = new System.Drawing.Point(171, 52);
            this.btnQueryState.Name = "btnQueryState";
            this.btnQueryState.Size = new System.Drawing.Size(75, 23);
            this.btnQueryState.TabIndex = 2;
            this.btnQueryState.Text = "查询状态";
            this.btnQueryState.UseVisualStyleBackColor = true;
            this.btnQueryState.Click += new System.EventHandler(this.btnQueryState_Click);
            // 
            // btnBright
            // 
            this.btnBright.Location = new System.Drawing.Point(252, 52);
            this.btnBright.Name = "btnBright";
            this.btnBright.Size = new System.Drawing.Size(75, 23);
            this.btnBright.TabIndex = 3;
            this.btnBright.Text = "灯闪";
            this.btnBright.UseVisualStyleBackColor = true;
            this.btnBright.Click += new System.EventHandler(this.btnBright_Click);
            // 
            // txtData
            // 
            this.txtData.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.txtData.Location = new System.Drawing.Point(0, 111);
            this.txtData.Name = "txtData";
            this.txtData.Size = new System.Drawing.Size(983, 437);
            this.txtData.TabIndex = 4;
            this.txtData.Text = "";
            // 
            // btnCall
            // 
            this.btnCall.Location = new System.Drawing.Point(333, 52);
            this.btnCall.Name = "btnCall";
            this.btnCall.Size = new System.Drawing.Size(75, 23);
            this.btnCall.TabIndex = 5;
            this.btnCall.Text = "响铃";
            this.btnCall.UseVisualStyleBackColor = true;
            this.btnCall.Click += new System.EventHandler(this.btnCall_Click);
            // 
            // btnOpenBattery
            // 
            this.btnOpenBattery.Location = new System.Drawing.Point(414, 52);
            this.btnOpenBattery.Name = "btnOpenBattery";
            this.btnOpenBattery.Size = new System.Drawing.Size(75, 23);
            this.btnOpenBattery.TabIndex = 6;
            this.btnOpenBattery.Text = "开电池仓";
            this.btnOpenBattery.UseVisualStyleBackColor = true;
            this.btnOpenBattery.Click += new System.EventHandler(this.btnOpenBattery_Click);
            // 
            // btnSetMaxSpeed
            // 
            this.btnSetMaxSpeed.Location = new System.Drawing.Point(495, 52);
            this.btnSetMaxSpeed.Name = "btnSetMaxSpeed";
            this.btnSetMaxSpeed.Size = new System.Drawing.Size(75, 23);
            this.btnSetMaxSpeed.TabIndex = 7;
            this.btnSetMaxSpeed.Text = "设置速度";
            this.btnSetMaxSpeed.UseVisualStyleBackColor = true;
            this.btnSetMaxSpeed.Click += new System.EventHandler(this.btnSetMaxSpeed_Click);
            // 
            // btnUpgrade
            // 
            this.btnUpgrade.Location = new System.Drawing.Point(576, 52);
            this.btnUpgrade.Name = "btnUpgrade";
            this.btnUpgrade.Size = new System.Drawing.Size(75, 23);
            this.btnUpgrade.TabIndex = 8;
            this.btnUpgrade.Text = "升级";
            this.btnUpgrade.UseVisualStyleBackColor = true;
            this.btnUpgrade.Click += new System.EventHandler(this.btnUpgrade_Click);
            // 
            // btnSetAlarm
            // 
            this.btnSetAlarm.Location = new System.Drawing.Point(657, 52);
            this.btnSetAlarm.Name = "btnSetAlarm";
            this.btnSetAlarm.Size = new System.Drawing.Size(75, 23);
            this.btnSetAlarm.TabIndex = 9;
            this.btnSetAlarm.Text = "是否报警";
            this.btnSetAlarm.UseVisualStyleBackColor = true;
            this.btnSetAlarm.Click += new System.EventHandler(this.btnSetAlarm_Click);
            // 
            // txtSN
            // 
            this.txtSN.Location = new System.Drawing.Point(49, 12);
            this.txtSN.Name = "txtSN";
            this.txtSN.Size = new System.Drawing.Size(222, 25);
            this.txtSN.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(31, 15);
            this.label1.TabIndex = 11;
            this.label1.Text = "SN:";
            // 
            // btnConnect
            // 
            this.btnConnect.Location = new System.Drawing.Point(468, 15);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(75, 23);
            this.btnConnect.TabIndex = 12;
            this.btnConnect.Text = "连接";
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(549, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 15);
            this.label2.TabIndex = 13;
            this.label2.Text = "SN:";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(883, 19);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 14;
            this.button1.Text = "清空";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnSet
            // 
            this.btnSet.Location = new System.Drawing.Point(9, 81);
            this.btnSet.Name = "btnSet";
            this.btnSet.Size = new System.Drawing.Size(75, 23);
            this.btnSet.TabIndex = 15;
            this.btnSet.Text = "设置";
            this.btnSet.UseVisualStyleBackColor = true;
            this.btnSet.Click += new System.EventHandler(this.btnSet_Click);
            // 
            // btnGet
            // 
            this.btnGet.Location = new System.Drawing.Point(90, 81);
            this.btnGet.Name = "btnGet";
            this.btnGet.Size = new System.Drawing.Size(75, 23);
            this.btnGet.TabIndex = 16;
            this.btnGet.Text = "获取";
            this.btnGet.UseVisualStyleBackColor = true;
            this.btnGet.Click += new System.EventHandler(this.btnGet_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(983, 548);
            this.Controls.Add(this.btnGet);
            this.Controls.Add(this.btnSet);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnConnect);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtSN);
            this.Controls.Add(this.btnSetAlarm);
            this.Controls.Add(this.btnUpgrade);
            this.Controls.Add(this.btnSetMaxSpeed);
            this.Controls.Add(this.btnOpenBattery);
            this.Controls.Add(this.btnCall);
            this.Controls.Add(this.txtData);
            this.Controls.Add(this.btnBright);
            this.Controls.Add(this.btnQueryState);
            this.Controls.Add(this.btnLock);
            this.Controls.Add(this.btnOpenLock);
            this.Name = "Form1";
            this.Text = "Client";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnOpenLock;
        private System.Windows.Forms.Button btnLock;
        private System.Windows.Forms.Button btnQueryState;
        private System.Windows.Forms.Button btnBright;
        private System.Windows.Forms.RichTextBox txtData;
        private System.Windows.Forms.Button btnCall;
        private System.Windows.Forms.Button btnOpenBattery;
        private System.Windows.Forms.Button btnSetMaxSpeed;
        private System.Windows.Forms.Button btnUpgrade;
        private System.Windows.Forms.Button btnSetAlarm;
        private System.Windows.Forms.TextBox txtSN;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnSet;
        private System.Windows.Forms.Button btnGet;
    }
}

