﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Comm;
using Newtonsoft.Json;

namespace CMDTEST
{

    public class HttpClass
    {
        public static string SendPostJson(string url, string jsonStr)
        {
            int timeOut = Convert.ToInt32(ConfigurationManager.AppSettings["ReceiveTimeOut"]);

            string result = "";
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            request.Method = "POST";
            request.ContentType = "application/json";
            request.Timeout = timeOut * 1000;

            #region 添加Post 参数  
            using (StreamWriter reqStream = new StreamWriter(request.GetRequestStream()))
            {
                reqStream.Write(jsonStr);
                reqStream.Flush();
                reqStream.Close();
            }
            #endregion

            HttpWebResponse resp = (HttpWebResponse)request.GetResponse();
            Stream stream = resp.GetResponseStream();
            //获取响应内容  
            using (StreamReader reader = new StreamReader(stream, Encoding.UTF8))
            {
                result = reader.ReadToEnd();
            }
            return result;
        }

        private static string SendPostBytes(string url, byte[] postBuffer)
        {
            int timeOut = Convert.ToInt32(ConfigurationManager.AppSettings["ReceiveTimeOut"]);

            string result = "";
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            request.Method = "POST";
            request.ContentType = "binary/octet-stream";
            request.ContentLength = postBuffer.Length;
            request.Timeout = timeOut * 1000;

            #region 添加Post 参数  
            using (Stream reqStream = request.GetRequestStream())
            {
                reqStream.Write(postBuffer, 0, postBuffer.Length);
                reqStream.Flush();
                reqStream.Close();
                //reqStream.Dispose();
            }
            #endregion

            HttpWebResponse resp = (HttpWebResponse)request.GetResponse();
            using (Stream stream = resp.GetResponseStream())
            {
                //获取响应内容  
                using (StreamReader reader = new StreamReader(stream, Encoding.UTF8))
                {
                    result = reader.ReadToEnd();
                }
            }
            return result;
        }


        private static byte[] CreateCommandBytes(string sn, BicycleCMDEnum cmd, Hashtable subHts, int msgSeq)
        {
            byte[] buffer = new byte[1024];
            try
            {
                //string sn = controllerModel.ControllerNo;//原SN
                string enSn = Commons.Encryption(sn);//加密后的SN
                Hashtable ht = new Hashtable();
                ht.Add("sn", enSn);
                ht.Add("cmdID", cmd.GetHashCode());

                if (subHts != null)
                {
                    ht.Add("argument", subHts);
                }
                buffer = ProtocolUtils.encode(ProtocolCmIdEnum.CMD_REQ.GetHashCode(), ht, msgSeq);
            }
            catch (Exception ex)
            {

            }
            return buffer;
        }

        /// <summary>
        /// Http发送指令
        /// </summary>
        /// <param name="sn"></param>
        /// <param name="cmd"></param>
        /// <param name="subHts"></param>
        /// <param name="msgSeq"></param>
        /// <returns></returns>
        public static ReportDataModel HttpSendCmd(string sn, BicycleCMDEnum cmd, Hashtable subHts, int msgSeq)
        {
            ReportDataModel model = null;
            if (string.IsNullOrEmpty(sn) || !sn.Substring(0, 6).Equals("mimacx"))
            {
                return model;
            }
            try
            {
                string url = ConfigurationManager.AppSettings["HttpCmdUrl"];
                byte[] buffer = CreateCommandBytes(sn, cmd, subHts, msgSeq);
                string json = SendPostBytes(url, buffer);
                model = GetReportData(json);
            }
            catch (Exception ex)
            {
                //
            }
            return model;
        }

        public static bool HttpSendCmdSetPropety(ProtocolCmIdEnum cmd, Hashtable ht, int msgSeq)
        {
            bool result = false;
            try
            {
                string url = ConfigurationManager.AppSettings["HttpCmdUrl"];
                byte[] buffer = ProtocolUtils.encode(cmd.GetHashCode(), ht, msgSeq);
                string json = SendPostBytes(url, buffer);
                if (string.IsNullOrEmpty(json))
                {
                    return result;
                }
                ProtocolSETRespModel setRespModel = JsonConvert.DeserializeObject<ProtocolSETRespModel>(json);
                if (setRespModel == null)
                {
                    return result;
                }
                if (setRespModel.result != 0)
                {
                    return result;
                }
                result = true;
            }
            catch (Exception ex)
            {

            }
            return result;
        }

        public static ProtocolGETRespModel HttpSendCmdGetPropety(ProtocolCmIdEnum cmd, Hashtable ht, int msgSeq)
        {
            ProtocolGETRespModel getRespModel = null;
            try
            {
                string url = ConfigurationManager.AppSettings["HttpCmdUrl"];
                byte[] buffer = ProtocolUtils.encode(cmd.GetHashCode(), ht, msgSeq);
                string json = SendPostBytes(url, buffer);
                if (string.IsNullOrEmpty(json))
                {
                    return getRespModel;
                }
                getRespModel = JsonConvert.DeserializeObject<ProtocolGETRespModel>(json);
            }
            catch (Exception ex)
            {

            }
            return getRespModel;
        }


        private static ReportDataModel GetReportData(string json)
        {
            ReportDataModel reportData = null;
            if (string.IsNullOrEmpty(json))
            {
                return reportData;
            }
            HttpPayload cmdRespModel = JsonConvert.DeserializeObject<HttpPayload>(json);
            if (cmdRespModel == null)
            {
                return reportData;
            }
            if (cmdRespModel.result != 0)
            {
                return reportData;
            }
            reportData = new ReportDataModel();
            reportData.SN = Commons.DecryptionSN(cmdRespModel.sn);
            string coordinate = "0,0";
            if (cmdRespModel.data == null)
            {
                return reportData;
            }
            if (cmdRespModel.data.latitudeDegree != 0 && cmdRespModel.data.latitudeMinute != 0 && cmdRespModel.data.longitudeDegree != 0 && cmdRespModel.data.longitudeMinute != 0)
            {
                coordinate = Commons.ToCoordinates(cmdRespModel.data.latitudeMinute, cmdRespModel.data.latitudeDegree, cmdRespModel.data.longitudeMinute, cmdRespModel.data.longitudeDegree);
            }

            reportData.Coordinate = coordinate;
            reportData.SurplusBattery = Convert.ToInt32(cmdRespModel.data.battery);
            reportData.TotalKM = cmdRespModel.data.totalMileage;
            reportData.Satellite = cmdRespModel.data.satellite;
            reportData.ErrorCode = cmdRespModel.data.errorCode;
            return reportData;
        }



    }
}
