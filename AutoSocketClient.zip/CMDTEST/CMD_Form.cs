﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using Comm;
using Newtonsoft.Json;
using System.Collections;

namespace CMDTEST
{
    public partial class CMD_Form : Form
    {
        public CMD_Form()
        {
            InitializeComponent();
        }

        delegate void DelegateShowMessage(string message);

        //delegate void RecevieDelegate(Socket s, ref ProtocolModel protocolModel);



        Socket socketClient = null;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// 开锁
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnOpenLock_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(this.txtSN.Text))
            {
                MessageBox.Show("SN不能为空！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            string sn = this.txtSN.Text.Trim();

            ReportDataModel reportDataModel = HttpClass.HttpSendCmd(sn, BicycleCMDEnum.Open, null, MessageSeqEnum.UserCode.GetHashCode());

            string message = string.Empty;
            if (reportDataModel != null )
            {
                message = string.Format("payload:{0}", JsonConvert.SerializeObject(reportDataModel));
            }
            else
            {
                message = string.Format("SN：{0}开锁失败", sn);
            }
            this.showMessage(message);
        }
        /// <summary>
        /// 上锁
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnLock_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(this.txtSN.Text))
            {
                MessageBox.Show("SN不能为空！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            string sn = this.txtSN.Text.Trim();

            ReportDataModel reportDataModel = HttpClass.HttpSendCmd(sn, BicycleCMDEnum.Lock, null, MessageSeqEnum.UserCode.GetHashCode());

            string message = string.Empty;
            if (reportDataModel != null)
            {
                message = string.Format("payload:{0}", JsonConvert.SerializeObject(reportDataModel));
            }
            else
            {
                message = string.Format("SN：{0}上锁失败", sn);
            }
            this.showMessage(message);
        }
        /// <summary>
        /// 查询车辆状态
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnQueryState_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(this.txtSN.Text))
            {
                MessageBox.Show("SN不能为空！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            string sn = this.txtSN.Text.Trim();

            ReportDataModel reportDataModel = HttpClass.HttpSendCmd(sn, BicycleCMDEnum.QueryState, null, MessageSeqEnum.OperCode.GetHashCode());

            string message = string.Empty;
            if (reportDataModel != null)
            {
                message = string.Format("payload:{0}", JsonConvert.SerializeObject(reportDataModel));
            }
            else
            {
                message = string.Format("SN：{0}查询车辆状态失败", sn);
            }
            this.showMessage(message);

        }
        /// <summary>
        /// 大灯闪
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnBright_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(this.txtSN.Text))
            {
                MessageBox.Show("SN不能为空！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            string sn = this.txtSN.Text.Trim();

            ReportDataModel reportDataModel = HttpClass.HttpSendCmd(sn, BicycleCMDEnum.Bright, null, MessageSeqEnum.UserCode.GetHashCode());

            string message = string.Empty;
            if (reportDataModel != null)
            {
                message = string.Format("payload:{0}", JsonConvert.SerializeObject(reportDataModel));
            }
            else
            {
                message = string.Format("SN：{0}大灯闪失败", sn);
            }
            this.showMessage(message);

        }
        /// <summary>
        /// 寻车响铃
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCall_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(this.txtSN.Text))
            {
                MessageBox.Show("SN不能为空！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            string sn = this.txtSN.Text.Trim();

            ReportDataModel reportDataModel = HttpClass.HttpSendCmd(sn, BicycleCMDEnum.Call, null, MessageSeqEnum.UserCode.GetHashCode());

            string message = string.Empty;
            if (reportDataModel != null)
            {
                message = string.Format("payload:{0}", JsonConvert.SerializeObject(reportDataModel));
            }
            else
            {
                message = string.Format("SN：{0}寻车响铃失败", sn);
            }
            this.showMessage(message);
        }
        /// <summary>
        /// 打开电池仓
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnOpenBattery_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(this.txtSN.Text))
            {
                MessageBox.Show("SN不能为空！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            string sn = this.txtSN.Text.Trim();
        }
        /// <summary>
        /// 设置最大行驶速度
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSetMaxSpeed_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(this.txtSN.Text))
            {
                MessageBox.Show("SN不能为空！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            string sn = this.txtSN.Text.Trim();
        }
        /// <summary>
        /// OTA升级
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnUpgrade_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(this.txtSN.Text))
            {
                MessageBox.Show("SN不能为空！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            string sn = this.txtSN.Text.Trim();
        }
        /// <summary>
        /// 设置是否报警
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSetAlarm_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(this.txtSN.Text))
            {
                MessageBox.Show("SN不能为空！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            string sn = this.txtSN.Text.Trim();
        }

        private void showMessage(string messages)
        {
            if (!this.label1.InvokeRequired)
            {
                this.txtData.Text += string.Format("{0}:{1}\r\n", DateTime.Now, messages);
            }
            else
            {
                DelegateShowMessage deleShow = new DelegateShowMessage(showMessage);
                this.label1.Invoke(deleShow, messages);
            }
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            //socketClient = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            //if (SocketClients.Connection(socketClient))
            //{
            //    this.label2.Text = (string.Format("连接服务器{0}成功！", socketClient.LocalEndPoint.ToString()));
            //}
        }

        delegate void delegateEnvent();

        private void button1_Click(object sender, EventArgs e)
        {
            this.txtData.Text = string.Empty;
        }

        /// <summary>
        /// 设置
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSet_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(this.txtSN.Text))
            {
                MessageBox.Show("SN不能为空！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            string sn = this.txtSN.Text.Trim();
           
        }

        /// <summary>
        /// 获取
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnGet_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(this.txtSN.Text))
            {
                MessageBox.Show("SN不能为空！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            string sn = this.txtSN.Text.Trim();
          
        }
    }
}
