﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using Comm;
using System.Configuration;
using System.Text.RegularExpressions;
using System.Threading;

namespace WFApiTestProjcet
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private string bikeNumber = string.Empty;
        private string userSessionKey = string.Empty;

        delegate void ShowMessageDelegate(string text);

        private string mimacxtimeSpan = "1513649300";
        private string mimacxSign = "08ac47ea49542b863ae67721ca7137e9";
        private string Lat = "31.277528047970282";
        private string Lon = "120.53383998008243";
        private string appVersion = "1.3.60";
        private string isBTOpen = "close";

        private string isForceBack = "0";
        private string operationType = "Api";
        private string isNormalCost = "1";
        private string useAmount = "0";
        private string moveAmount = "0";

        System.Timers.Timer openTimer = null;

        System.Timers.Timer lockTimer = null;

        /// <summary>
        /// 借车
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnTake_Click(object sender, EventArgs e)
        {
            Take(null, null);
        }

        private void Take(object sender, System.Timers.ElapsedEventArgs e)
        {
            string operationUrl = ConfigurationManager.AppSettings["OperationUrl"];
            string takeUrl = operationUrl + "/BikeCoreUse/TakeBy2G";
            //string takeUrl = "http://116.62.246.156:9006/BikeCoreUse/TakeBy2G";
            //string takeUrl = "http://localhost:59505/BikeCoreUse/TakeBy2G";

            string sessionKey = this.txtSessionKey.Text.Trim();
            if (string.IsNullOrEmpty(sessionKey))
            {
                MessageBox.Show("SessionKey不能为空", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            string bikeNumber = this.txtBikeNumber.Text.Trim();
            if (string.IsNullOrEmpty(bikeNumber))
            {
                MessageBox.Show("BikeNumber不能为空", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            Hashtable ht = new Hashtable();
            ht.Add("SessionKey", sessionKey);
            ht.Add("BicycleNo", bikeNumber);
            ht.Add("mimacxtimeSpan", mimacxtimeSpan);
            ht.Add("mimacxSign", mimacxSign);
            ht.Add("Lat", Lat);
            ht.Add("Lon", Lon);
            ht.Add("AppVersion", appVersion);
            ht.Add("IsBTOpen", isBTOpen);
            string jsonStr = JsonConvert.SerializeObject(ht);
            string result = HttpClass.SendPostJson(takeUrl, jsonStr);

            ReturnMesModel model = JsonConvert.DeserializeObject<ReturnMesModel>(result);
            if (model != null && model.returnCode.Equals("0"))
            {
                this.ShowMessage(string.Format("{0},借车成功", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")));
                backBike(null, null);
            }
            else
            {
                this.ShowMessage(string.Format("{0},借车失败,Msg:{1}", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), model.returnMsg));
            }

        }

        /// <summary>
        /// 还车
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnBack_Click(object sender, EventArgs e)
        {
            backBike(null, null);
        }

        private void backBike(object sender, System.Timers.ElapsedEventArgs e)
        {
            string operationUrl = ConfigurationManager.AppSettings["OperationUrl"];
            string backUrl = operationUrl + "/BikeCoreUse/BackBy2GNew";
            //string backUrl = "http://116.62.246.156:9006/BikeCoreUse/BackBy2GNew";
            //string backUrl = "http://localhost:59505/BikeCoreUse/BackBy2GNew";

            string sessionKey = this.txtSessionKey.Text.Trim();
            if (string.IsNullOrEmpty(sessionKey))
            {
                MessageBox.Show("SessionKey不能为空", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            string bikeNumber = this.txtBikeNumber.Text.Trim();
            if (string.IsNullOrEmpty(bikeNumber))
            {
                MessageBox.Show("BikeNumber不能为空", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Hashtable ht = new Hashtable();
            ht.Add("SessionKey", sessionKey);
            ht.Add("BicycleNo", bikeNumber);
            ht.Add("mimacxtimeSpan", mimacxtimeSpan);
            ht.Add("mimacxSign", mimacxSign);
            ht.Add("latitude", Lat);
            ht.Add("longitude", Lon);
            ht.Add("AppVersion", appVersion);
            ht.Add("IsBTOpen", isBTOpen);

            ht.Add("IsForceBack", isForceBack);
            ht.Add("OperationType", operationType);
            ht.Add("IsNormalCost", isNormalCost);
            ht.Add("UseAmount", useAmount);
            ht.Add("MoveAmount", moveAmount);

            string jsonStr = JsonConvert.SerializeObject(ht);
            string result = HttpClass.SendPostJson(backUrl, jsonStr);
            ReturnMesModel model = JsonConvert.DeserializeObject<ReturnMesModel>(result);
            if (model != null && model.returnCode.Equals("0"))
            {
                this.ShowMessage(string.Format("{0},还车成功", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")));
                payMoney();
            }
            else
            {
                this.ShowMessage(string.Format("{0},还车失败,Msg:{1}", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), model.returnMsg));
            }
        }

        private void payMoney()
        {
            string operationUrl = ConfigurationManager.AppSettings["OperationUrl"];
            string backUrl = operationUrl + "/BikeCoreUse/PayMoney";
            //string backUrl = "http://116.62.246.156:9006/BikeCoreUse/PayMoney";
            //string backUrl = "http://localhost:59506/BikeCoreUse/PayMoney";

            string sessionKey = this.txtSessionKey.Text.Trim();
            if (string.IsNullOrEmpty(sessionKey))
            {
                MessageBox.Show("SessionKey不能为空", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            Hashtable ht = new Hashtable();
            ht.Add("SessionKey", sessionKey);
            ht.Add("AppVersion", appVersion);

            string jsonStr = JsonConvert.SerializeObject(ht);
            string result = HttpClass.SendPostJson(backUrl, jsonStr);
            ReturnMesModel model = JsonConvert.DeserializeObject<ReturnMesModel>(result);
            if (model != null && model.returnCode.Equals("0"))
            {
                this.ShowMessage(string.Format("{0},付款成功", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")));
            }
            else
            {
                this.ShowMessage(string.Format("{0},付款失败,Msg:{1}", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), model.returnMsg));
            }

        }



        private void btnStart_Click(object sender, EventArgs e)
        {
            double intervalTime = 60;
            string intervalTimeStr = ConfigurationManager.AppSettings["IntervalTime"];
            if (!string.IsNullOrEmpty(intervalTimeStr))
            {
                intervalTime = Convert.ToDouble(intervalTimeStr);
            }

            System.Timers.Timer timer = new System.Timers.Timer();
            timer.Interval = intervalTime * 1000;
            timer.Elapsed += Take;
            timer.AutoReset = true;
            timer.Enabled = true;
            Take(null, null);
            timer.Start();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            this.richTextBox1.Text = string.Empty;
        }

        private void ShowMessage(string str)
        {

            if (this.richTextBox1.InvokeRequired)
            {

                ShowMessageDelegate showDelegate = new ShowMessageDelegate(ShowMessage);
                this.Invoke(showDelegate, str);
            }
            else
            {
                this.richTextBox1.Text += str + "\r\n";
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.txtBikeNumber.Text = ConfigurationManager.AppSettings["BikeNumber"].ToString();
            this.txtSessionKey.Text = ConfigurationManager.AppSettings["UserSessionKey"].ToString();

            openTimer = new System.Timers.Timer();
            openTimer.Interval = 5 * 60 * 1000;
            openTimer.Elapsed += Open;
            openTimer.AutoReset = true;
            openTimer.Enabled = false;

            lockTimer = new System.Timers.Timer();
            lockTimer.Interval = 5 * 60 * 1000;
            lockTimer.Elapsed += Lock;
            lockTimer.AutoReset = true;
            lockTimer.Enabled = false;

        }

        private void btnPay_Click(object sender, EventArgs e)
        {
            payMoney();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sn = this.txtSystemNumber.Text.Trim();
            ReportDataModel reportDataModel = HttpClass.HttpSendCmd(sn, BicycleCMDEnum.Open, null, MessageSeqEnum.UserCode.GetHashCode());
            if (reportDataModel == null)
            {
                MessageBox.Show("开锁失败!", "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                MessageBox.Show("开锁成功!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            //for (int i = 0; i < 50; i++)
            //{
            //    ReportDataModel reportDataModel = HttpClass.HttpSendCmd(sn, BicycleCMDEnum.Open, null, MessageSeqEnum.UserCode.GetHashCode());
            //}
            //MessageBox.Show("开锁成功");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string sn = this.txtSystemNumber.Text.Trim();
            ReportDataModel reportDataModel = HttpClass.HttpSendCmd(sn, BicycleCMDEnum.Lock, null, MessageSeqEnum.UserCode.GetHashCode());
            if (reportDataModel == null)
            {
                MessageBox.Show("上锁失败!", "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                MessageBox.Show("上锁成功!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            //for (int i = 0; i < 50; i++)
            //{
            //    ReportDataModel reportDataModel = HttpClass.HttpSendCmd(sn, BicycleCMDEnum.Lock, null, MessageSeqEnum.UserCode.GetHashCode());
            //    Thread.Sleep(20);
            //}
            MessageBox.Show("上锁成功");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string str = "ddsadfa,protocolMsgSeq:101,[18362627616]用户借车失败(开锁失败(开锁失败且未开蓝牙))";
            int index = str.IndexOf("protocolMsgSeq");
            if (index > 0)
            {
                string dd = str.Substring(index + 15, 3);
            }


            Regex reg = new Regex(@"\[(.*)(?:\])");
            string s = reg.Match(str).Value;
            if (!str.Contains("("))
            {
                string s1 = str.Substring(str.IndexOf("]"));
            }
            else
            {
                Regex reg1 = new Regex(@"\((.*)(?:\))");
                string s2 = reg1.Match(str).Value;
                string s3 = str.Replace(s, string.Empty).Replace(s2, string.Empty);
            }


            MessageBox.Show("上锁成功");
        }

        private void btnCall_Click(object sender, EventArgs e)
        {
            string sn = this.txtSystemNumber.Text.Trim();
            ReportDataModel reportDataModel = HttpClass.HttpSendCmd(sn, BicycleCMDEnum.Call, null, MessageSeqEnum.UserCode.GetHashCode());
            if (reportDataModel == null)
            {
                MessageBox.Show("响铃失败!", "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                MessageBox.Show("响铃成功!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }

        private void btnBright_Click(object sender, EventArgs e)
        {
            string sn = this.txtSystemNumber.Text.Trim();
            ReportDataModel reportDataModel = HttpClass.HttpSendCmd(sn, BicycleCMDEnum.Bright, null, MessageSeqEnum.UserCode.GetHashCode());
            if (reportDataModel == null)
            {
                MessageBox.Show("闪灯失败!", "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                MessageBox.Show("闪灯成功!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnVoice_Click(object sender, EventArgs e)
        {
            string sn = this.txtSystemNumber.Text.Trim();
            string voiceId = this.txtVioce.Text.Trim();
            Hashtable ht = new Hashtable();
            ht.Add("voiceId", voiceId);
            ReportDataModel reportDataModel = HttpClass.HttpSendCmd(sn, BicycleCMDEnum.Voice, ht, MessageSeqEnum.UserCode.GetHashCode());
            if (reportDataModel == null)
            {
                MessageBox.Show("响语音失败!", "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                MessageBox.Show("响语音成功!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }



        private void Open(object sender, System.Timers.ElapsedEventArgs e)
        {
            for (int i = 0; i < 700; i++)
            {
                string snNumber = (i + 100).ToString();
                string countStr = new string('0', 10 - snNumber.ToString().Length);
                string sn = string.Concat("mimacx", countStr, snNumber);

                Thread.Sleep(300);
                HttpClass httpClass = new HttpClass();
                httpClass.HttpSendCmdAsync(sn, BicycleCMDEnum.Open, null, MessageSeqEnum.UserCode.GetHashCode());
            }
        }


        private void Lock(object sender, System.Timers.ElapsedEventArgs e)
        {
            for (int i = 0; i < 700; i++)
            {
                string snNumber = (i + 100).ToString();
                string countStr = new string('0', 10 - snNumber.ToString().Length);
                string sn = string.Concat("mimacx", countStr, snNumber);

                Thread.Sleep(300);
                HttpClass httpClass = new HttpClass();
                httpClass.HttpSendCmdAsync(sn, BicycleCMDEnum.Lock, null, MessageSeqEnum.UserCode.GetHashCode());
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.openTimer.Stop();
            Open(null, null);
            this.lockTimer.Start();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Hashtable ht = new Hashtable();
            ht.Add("sn", Commons.Encryption("mimacx0000000130"));
            ht.Add("opname", "get");
            ht.Add("paramname", "GSM");

            ProtocolGETRespModel getRespModel = HttpClass.HttpSendCmdGetPropety(ProtocolCmIdEnum.GET_REQ, ht, MessageSeqEnum.OperCode.GetHashCode());

            string code = "0", msg = "获取失败"; object data = null;
            if (getRespModel != null)
            {
                code = "1"; msg = "获取成功"; data = getRespModel;
            }
        }

        private void btnQuery_Click(object sender, EventArgs e)
        {
            string sn = this.txtSystemNumber.Text.Trim();
            ReportDataModel reportDataModel = HttpClass.HttpSendCmd(sn, BicycleCMDEnum.QueryState, null, MessageSeqEnum.UserCode.GetHashCode());
            if (reportDataModel == null)
            {
                MessageBox.Show("开锁失败!", "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                MessageBox.Show("开锁成功!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnSetSpeed_Click(object sender, EventArgs e)
        {
            string sn = this.txtSystemNumber.Text.Trim();
            Hashtable subHts = new Hashtable();
            subHts.Add("maxSpeed", 100);
            ReportDataModel reportModel = HttpClass.HttpSendCmd(sn, BicycleCMDEnum.SetMaxSpeed, subHts, MessageSeqEnum.OperCode.GetHashCode());
            if (reportModel == null)
            {
                MessageBox.Show("设置失败!", "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                MessageBox.Show("设置成功!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}
