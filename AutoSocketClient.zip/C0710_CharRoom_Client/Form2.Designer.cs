﻿namespace Bicycles_Client
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtLatMinute = new System.Windows.Forms.TextBox();
            this.txtlonMinute = new System.Windows.Forms.TextBox();
            this.txtLonDeg = new System.Windows.Forms.TextBox();
            this.txtLatDeg = new System.Windows.Forms.TextBox();
            this.txtCoordinates = new System.Windows.Forms.TextBox();
            this.LonMinute = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.LatMinute = new System.Windows.Forms.Label();
            this.txtGPS = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnCoordinates = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.txtCellId = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.MqttAlarmTextBox = new System.Windows.Forms.TextBox();
            this.txtBattery = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtAlarmType = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.btnMqttAlarm = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.label28 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtLatMinute
            // 
            this.txtLatMinute.Location = new System.Drawing.Point(87, 69);
            this.txtLatMinute.Name = "txtLatMinute";
            this.txtLatMinute.ReadOnly = true;
            this.txtLatMinute.Size = new System.Drawing.Size(112, 21);
            this.txtLatMinute.TabIndex = 69;
            // 
            // txtlonMinute
            // 
            this.txtlonMinute.Location = new System.Drawing.Point(281, 69);
            this.txtlonMinute.Name = "txtlonMinute";
            this.txtlonMinute.ReadOnly = true;
            this.txtlonMinute.Size = new System.Drawing.Size(109, 21);
            this.txtlonMinute.TabIndex = 68;
            // 
            // txtLonDeg
            // 
            this.txtLonDeg.Location = new System.Drawing.Point(281, 44);
            this.txtLonDeg.Name = "txtLonDeg";
            this.txtLonDeg.ReadOnly = true;
            this.txtLonDeg.Size = new System.Drawing.Size(109, 21);
            this.txtLonDeg.TabIndex = 67;
            // 
            // txtLatDeg
            // 
            this.txtLatDeg.Location = new System.Drawing.Point(87, 44);
            this.txtLatDeg.Name = "txtLatDeg";
            this.txtLatDeg.ReadOnly = true;
            this.txtLatDeg.Size = new System.Drawing.Size(112, 21);
            this.txtLatDeg.TabIndex = 66;
            // 
            // txtCoordinates
            // 
            this.txtCoordinates.Location = new System.Drawing.Point(87, 18);
            this.txtCoordinates.Margin = new System.Windows.Forms.Padding(2);
            this.txtCoordinates.Name = "txtCoordinates";
            this.txtCoordinates.Size = new System.Drawing.Size(303, 21);
            this.txtCoordinates.TabIndex = 60;
            this.txtCoordinates.Text = "31.277528047970282,120.53383998008243";
            // 
            // LonMinute
            // 
            this.LonMinute.AutoSize = true;
            this.LonMinute.Location = new System.Drawing.Point(214, 73);
            this.LonMinute.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.LonMinute.Name = "LonMinute";
            this.LonMinute.Size = new System.Drawing.Size(65, 12);
            this.LonMinute.TabIndex = 65;
            this.LonMinute.Text = "lonMinute:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(45, 22);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 12);
            this.label5.TabIndex = 61;
            this.label5.Text = "坐标:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(598, 53);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(47, 12);
            this.label8.TabIndex = 73;
            this.label8.Text = "GPS星数";
            // 
            // LatMinute
            // 
            this.LatMinute.AutoSize = true;
            this.LatMinute.Location = new System.Drawing.Point(14, 73);
            this.LatMinute.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.LatMinute.Name = "LatMinute";
            this.LatMinute.Size = new System.Drawing.Size(65, 12);
            this.LatMinute.TabIndex = 64;
            this.LatMinute.Text = "latMinute:";
            // 
            // txtGPS
            // 
            this.txtGPS.Location = new System.Drawing.Point(650, 48);
            this.txtGPS.Margin = new System.Windows.Forms.Padding(2);
            this.txtGPS.Name = "txtGPS";
            this.txtGPS.Size = new System.Drawing.Size(32, 21);
            this.txtGPS.TabIndex = 74;
            this.txtGPS.Text = "7";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(29, 48);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 12);
            this.label6.TabIndex = 62;
            this.label6.Text = "latDeg:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(229, 48);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(47, 12);
            this.label7.TabIndex = 63;
            this.label7.Text = "lonDeg:";
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.btnCoordinates);
            this.groupBox1.Controls.Add(this.txtLatMinute);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.txtlonMinute);
            this.groupBox1.Controls.Add(this.txtCellId);
            this.groupBox1.Controls.Add(this.txtLonDeg);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.txtLatDeg);
            this.groupBox1.Controls.Add(this.MqttAlarmTextBox);
            this.groupBox1.Controls.Add(this.txtBattery);
            this.groupBox1.Controls.Add(this.txtCoordinates);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.LonMinute);
            this.groupBox1.Controls.Add(this.txtAlarmType);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.LatMinute);
            this.groupBox1.Controls.Add(this.txtGPS);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.btnMqttAlarm);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Location = new System.Drawing.Point(11, 351);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(1091, 106);
            this.groupBox1.TabIndex = 67;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "坐标系";
            // 
            // btnCoordinates
            // 
            this.btnCoordinates.Location = new System.Drawing.Point(414, 73);
            this.btnCoordinates.Name = "btnCoordinates";
            this.btnCoordinates.Size = new System.Drawing.Size(116, 23);
            this.btnCoordinates.TabIndex = 67;
            this.btnCoordinates.Text = "计算坐标";
            this.btnCoordinates.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(415, 22);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(53, 12);
            this.label11.TabIndex = 79;
            this.label11.Text = "基站ID：";
            // 
            // txtCellId
            // 
            this.txtCellId.Location = new System.Drawing.Point(472, 19);
            this.txtCellId.Margin = new System.Windows.Forms.Padding(2);
            this.txtCellId.Name = "txtCellId";
            this.txtCellId.Size = new System.Drawing.Size(117, 21);
            this.txtCellId.TabIndex = 80;
            this.txtCellId.Text = "460.00.20831.12002";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(412, 55);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(29, 12);
            this.label10.TabIndex = 77;
            this.label10.Text = "电量";
            // 
            // MqttAlarmTextBox
            // 
            this.MqttAlarmTextBox.Location = new System.Drawing.Point(900, 15);
            this.MqttAlarmTextBox.Margin = new System.Windows.Forms.Padding(2);
            this.MqttAlarmTextBox.Name = "MqttAlarmTextBox";
            this.MqttAlarmTextBox.Size = new System.Drawing.Size(156, 21);
            this.MqttAlarmTextBox.TabIndex = 51;
            this.MqttAlarmTextBox.Text = "mimacx0000030002";
            // 
            // txtBattery
            // 
            this.txtBattery.Location = new System.Drawing.Point(448, 50);
            this.txtBattery.Margin = new System.Windows.Forms.Padding(2);
            this.txtBattery.Name = "txtBattery";
            this.txtBattery.Size = new System.Drawing.Size(32, 21);
            this.txtBattery.TabIndex = 78;
            this.txtBattery.Text = "90";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(869, 43);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 12);
            this.label9.TabIndex = 75;
            this.label9.Text = "报警类型";
            // 
            // txtAlarmType
            // 
            this.txtAlarmType.Location = new System.Drawing.Point(934, 40);
            this.txtAlarmType.Margin = new System.Windows.Forms.Padding(2);
            this.txtAlarmType.Name = "txtAlarmType";
            this.txtAlarmType.Size = new System.Drawing.Size(32, 21);
            this.txtAlarmType.TabIndex = 76;
            this.txtAlarmType.Text = "0";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(872, 19);
            this.label21.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(23, 12);
            this.label21.TabIndex = 52;
            this.label21.Text = "SN:";
            // 
            // btnMqttAlarm
            // 
            this.btnMqttAlarm.Location = new System.Drawing.Point(871, 73);
            this.btnMqttAlarm.Name = "btnMqttAlarm";
            this.btnMqttAlarm.Size = new System.Drawing.Size(75, 23);
            this.btnMqttAlarm.TabIndex = 67;
            this.btnMqttAlarm.Text = "提交报警";
            this.btnMqttAlarm.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.button1);
            this.groupBox2.Controls.Add(this.textBox1);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.textBox2);
            this.groupBox2.Controls.Add(this.textBox3);
            this.groupBox2.Controls.Add(this.textBox4);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.textBox5);
            this.groupBox2.Controls.Add(this.textBox6);
            this.groupBox2.Controls.Add(this.textBox7);
            this.groupBox2.Controls.Add(this.textBox8);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.textBox9);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.textBox10);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.button2);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Location = new System.Drawing.Point(11, 229);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox2.Size = new System.Drawing.Size(1091, 106);
            this.groupBox2.TabIndex = 67;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "GCJ02坐标系（腾讯、高德）";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(414, 73);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(116, 23);
            this.button1.TabIndex = 67;
            this.button1.Text = "计算坐标";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(87, 69);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(112, 21);
            this.textBox1.TabIndex = 69;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(415, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 79;
            this.label1.Text = "基站ID：";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(281, 69);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(109, 21);
            this.textBox2.TabIndex = 68;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(472, 19);
            this.textBox3.Margin = new System.Windows.Forms.Padding(2);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(117, 21);
            this.textBox3.TabIndex = 80;
            this.textBox3.Text = "460.00.20831.12002";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(281, 44);
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(109, 21);
            this.textBox4.TabIndex = 67;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(412, 55);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 12);
            this.label2.TabIndex = 77;
            this.label2.Text = "电量";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(87, 44);
            this.textBox5.Name = "textBox5";
            this.textBox5.ReadOnly = true;
            this.textBox5.Size = new System.Drawing.Size(112, 21);
            this.textBox5.TabIndex = 66;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(900, 15);
            this.textBox6.Margin = new System.Windows.Forms.Padding(2);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(156, 21);
            this.textBox6.TabIndex = 51;
            this.textBox6.Text = "mimacx0000030002";
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(448, 50);
            this.textBox7.Margin = new System.Windows.Forms.Padding(2);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(32, 21);
            this.textBox7.TabIndex = 78;
            this.textBox7.Text = "90";
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(87, 18);
            this.textBox8.Margin = new System.Windows.Forms.Padding(2);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(303, 21);
            this.textBox8.TabIndex = 60;
            this.textBox8.Text = "31.277528047970282,120.53383998008243";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(869, 43);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 75;
            this.label3.Text = "报警类型";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(214, 73);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 12);
            this.label4.TabIndex = 65;
            this.label4.Text = "lonMinute:";
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(934, 40);
            this.textBox9.Margin = new System.Windows.Forms.Padding(2);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(32, 21);
            this.textBox9.TabIndex = 76;
            this.textBox9.Text = "0";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(45, 22);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(35, 12);
            this.label12.TabIndex = 61;
            this.label12.Text = "坐标:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(598, 53);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(47, 12);
            this.label13.TabIndex = 73;
            this.label13.Text = "GPS星数";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(14, 73);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(65, 12);
            this.label14.TabIndex = 64;
            this.label14.Text = "latMinute:";
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(650, 48);
            this.textBox10.Margin = new System.Windows.Forms.Padding(2);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(32, 21);
            this.textBox10.TabIndex = 74;
            this.textBox10.Text = "7";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(29, 48);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(47, 12);
            this.label15.TabIndex = 62;
            this.label15.Text = "latDeg:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(872, 19);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(23, 12);
            this.label16.TabIndex = 52;
            this.label16.Text = "SN:";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(871, 73);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 67;
            this.button2.Text = "提交报警";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(229, 48);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(47, 12);
            this.label17.TabIndex = 63;
            this.label17.Text = "lonDeg:";
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox3.Controls.Add(this.button3);
            this.groupBox3.Controls.Add(this.textBox11);
            this.groupBox3.Controls.Add(this.label18);
            this.groupBox3.Controls.Add(this.textBox12);
            this.groupBox3.Controls.Add(this.textBox13);
            this.groupBox3.Controls.Add(this.textBox14);
            this.groupBox3.Controls.Add(this.label19);
            this.groupBox3.Controls.Add(this.textBox15);
            this.groupBox3.Controls.Add(this.textBox16);
            this.groupBox3.Controls.Add(this.textBox17);
            this.groupBox3.Controls.Add(this.textBox18);
            this.groupBox3.Controls.Add(this.label20);
            this.groupBox3.Controls.Add(this.label22);
            this.groupBox3.Controls.Add(this.textBox19);
            this.groupBox3.Controls.Add(this.label23);
            this.groupBox3.Controls.Add(this.label24);
            this.groupBox3.Controls.Add(this.label25);
            this.groupBox3.Controls.Add(this.textBox20);
            this.groupBox3.Controls.Add(this.label26);
            this.groupBox3.Controls.Add(this.label27);
            this.groupBox3.Controls.Add(this.button4);
            this.groupBox3.Controls.Add(this.label28);
            this.groupBox3.Location = new System.Drawing.Point(11, 119);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox3.Size = new System.Drawing.Size(1091, 106);
            this.groupBox3.TabIndex = 67;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "wgs84坐标系（Google国外、硬件GPS、原始GPS、地球坐标系坐标）";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(414, 73);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(116, 23);
            this.button3.TabIndex = 67;
            this.button3.Text = "计算坐标";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(87, 69);
            this.textBox11.Name = "textBox11";
            this.textBox11.ReadOnly = true;
            this.textBox11.Size = new System.Drawing.Size(112, 21);
            this.textBox11.TabIndex = 69;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(415, 22);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(53, 12);
            this.label18.TabIndex = 79;
            this.label18.Text = "基站ID：";
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(281, 69);
            this.textBox12.Name = "textBox12";
            this.textBox12.ReadOnly = true;
            this.textBox12.Size = new System.Drawing.Size(109, 21);
            this.textBox12.TabIndex = 68;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(472, 19);
            this.textBox13.Margin = new System.Windows.Forms.Padding(2);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(117, 21);
            this.textBox13.TabIndex = 80;
            this.textBox13.Text = "460.00.20831.12002";
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(281, 44);
            this.textBox14.Name = "textBox14";
            this.textBox14.ReadOnly = true;
            this.textBox14.Size = new System.Drawing.Size(109, 21);
            this.textBox14.TabIndex = 67;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(412, 55);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(29, 12);
            this.label19.TabIndex = 77;
            this.label19.Text = "电量";
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(87, 44);
            this.textBox15.Name = "textBox15";
            this.textBox15.ReadOnly = true;
            this.textBox15.Size = new System.Drawing.Size(112, 21);
            this.textBox15.TabIndex = 66;
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(900, 15);
            this.textBox16.Margin = new System.Windows.Forms.Padding(2);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(156, 21);
            this.textBox16.TabIndex = 51;
            this.textBox16.Text = "mimacx0000030002";
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(448, 50);
            this.textBox17.Margin = new System.Windows.Forms.Padding(2);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(32, 21);
            this.textBox17.TabIndex = 78;
            this.textBox17.Text = "90";
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(87, 18);
            this.textBox18.Margin = new System.Windows.Forms.Padding(2);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(303, 21);
            this.textBox18.TabIndex = 60;
            this.textBox18.Text = "31.277528047970282,120.53383998008243";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(869, 43);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(53, 12);
            this.label20.TabIndex = 75;
            this.label20.Text = "报警类型";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(214, 73);
            this.label22.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(65, 12);
            this.label22.TabIndex = 65;
            this.label22.Text = "lonMinute:";
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(934, 40);
            this.textBox19.Margin = new System.Windows.Forms.Padding(2);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(32, 21);
            this.textBox19.TabIndex = 76;
            this.textBox19.Text = "0";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(45, 22);
            this.label23.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(35, 12);
            this.label23.TabIndex = 61;
            this.label23.Text = "坐标:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(598, 53);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(47, 12);
            this.label24.TabIndex = 73;
            this.label24.Text = "GPS星数";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(14, 73);
            this.label25.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(65, 12);
            this.label25.TabIndex = 64;
            this.label25.Text = "latMinute:";
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(650, 48);
            this.textBox20.Margin = new System.Windows.Forms.Padding(2);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(32, 21);
            this.textBox20.TabIndex = 74;
            this.textBox20.Text = "7";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(29, 48);
            this.label26.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(47, 12);
            this.label26.TabIndex = 62;
            this.label26.Text = "latDeg:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(872, 19);
            this.label27.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(23, 12);
            this.label27.TabIndex = 52;
            this.label27.Text = "SN:";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(871, 73);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 67;
            this.button4.Text = "提交报警";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(229, 48);
            this.label28.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(47, 12);
            this.label28.TabIndex = 63;
            this.label28.Text = "lonDeg:";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1138, 468);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form2";
            this.Text = "工具类";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox txtLatMinute;
        private System.Windows.Forms.TextBox txtlonMinute;
        private System.Windows.Forms.TextBox txtLonDeg;
        private System.Windows.Forms.TextBox txtLatDeg;
        private System.Windows.Forms.TextBox txtCoordinates;
        private System.Windows.Forms.Label LonMinute;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label LatMinute;
        private System.Windows.Forms.TextBox txtGPS;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnCoordinates;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtCellId;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox MqttAlarmTextBox;
        private System.Windows.Forms.TextBox txtBattery;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtAlarmType;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button btnMqttAlarm;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label28;
    }
}